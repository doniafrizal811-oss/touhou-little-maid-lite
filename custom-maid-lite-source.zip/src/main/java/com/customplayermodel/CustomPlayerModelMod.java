package com.customplayermodel;

import com.customplayermodel.entity.ModEntities;
import com.customplayermodel.entity.ModItems;
import com.customplayermodel.entity.MaidEntity;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CustomPlayerModelMod implements ModInitializer {
    public static final String MOD_ID = "customplayermodel";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("[CustomMaid] Inisialisasi mod v1.1.0...");

        // Daftarkan entity types
        ModEntities.register();

        // Daftarkan items (spawn egg, item group)
        ModItems.register();

        // Daftarkan attribute default maid
        FabricDefaultAttributeRegistry.register(
            ModEntities.MAID,
            MaidEntity.createMaidAttributes()
        );

        // Daftarkan network packets (server-side receivers)
        CPMNetwork.registerServerPackets();

        LOGGER.info("[CustomMaid] Siap! Fitur:");
        LOGGER.info("[CustomMaid]  - Model YSM dari config/customplayermodel/models/");
        LOGGER.info("[CustomMaid]  - Tekan M untuk pilih model player");
        LOGGER.info("[CustomMaid]  - Shift+Klik kanan maid → gendong maid");
        LOGGER.info("[CustomMaid]  - Klik kanan maid → duduk/berdiri");
    }
}
