package com.customplayermodel.mixin;

import com.customplayermodel.CPMServerState;
import com.customplayermodel.client.model.CPMModelData;
import com.customplayermodel.client.model.CPMModelManager;
import com.customplayermodel.client.renderer.CPMPlayerRenderer;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Optional;

/**
 * Mixin: intercept render player untuk ganti model dengan YSM custom.
 * Hanya aktif jika player punya model yang terdaftar di CPMServerState.
 * Jika tidak → render vanilla seperti biasa.
 */
@Mixin(PlayerEntityRenderer.class)
public class PlayerEntityRendererMixin {

    @Inject(
        method = "render(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
        at = @At("HEAD"),
        cancellable = true
    )
    private void onRender(
        AbstractClientPlayerEntity player,
        float yaw,
        float tickDelta,
        MatrixStack matrices,
        VertexConsumerProvider vertexConsumers,
        int light,
        CallbackInfo ci
    ) {
        // Ambil model ID dari server state (tersinkron via packet)
        String modelId = CPMServerState.getPlayerModel(player.getUuid());
        if (modelId == null || modelId.isBlank()) return; // tidak ada model custom, render vanilla

        Optional<CPMModelData> modelData = CPMModelManager.getInstance().getModel(modelId);
        if (modelData.isEmpty()) return; // model belum dimuat / tidak ditemukan, render vanilla

        // Render custom YSM model, batalkan render vanilla
        CPMPlayerRenderer.render(player, modelData.get(), yaw, tickDelta,
                matrices, vertexConsumers, light);
        ci.cancel();
    }
}
