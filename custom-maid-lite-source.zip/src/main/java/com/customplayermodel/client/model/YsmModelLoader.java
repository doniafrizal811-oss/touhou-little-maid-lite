package com.customplayermodel.client.model;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * Parser model format YSM (Yes Steve Model) / Bedrock geometry JSON.
 *
 * Format yang didukung:
 * 1. Format YSM: {"meta":{"type":"ysm_model",...}, "texture":"...", "bones":[...]}
 * 2. Format Bedrock: {"format_version":"1.12.0", "minecraft:geometry":[{"bones":[...]}]}
 * 3. Format sederhana (format internal mod ini): {"name":"...", "texture":"...", "bones":[...]}
 *
 * Renderer menggunakan data BoneGroup ini untuk menggambar box di setiap tulang.
 *
 * Catatan performa: parser hanya jalan sekali saat model dimuat pertama kali (lazy load).
 * Hasil disimpan di LRU cache max 10 model (CPMModelManager). Hemat RAM.
 */
public class YsmModelLoader {

    /**
     * Satu "kotak" (cube) dalam model.
     * origin = posisi sudut bawah-kiri-depan dalam ruang model (pixel unit)
     * size   = ukuran W x H x D
     * uv     = koordinat UV pojok kiri-atas di texture sheet
     */
    public static class Cube {
        public final float ox, oy, oz;       // origin
        public final float sx, sy, sz;       // size
        public final float u, v;             // UV start
        public final float rot;              // rotasi ekstra (opsional, derajat)

        public Cube(float ox, float oy, float oz,
                    float sx, float sy, float sz,
                    float u, float v, float rot) {
            this.ox = ox; this.oy = oy; this.oz = oz;
            this.sx = sx; this.sy = sy; this.sz = sz;
            this.u  = u;  this.v  = v;
            this.rot = rot;
        }
    }

    /**
     * Satu "tulang" yang bisa punya anak dan beberapa cube.
     * Posisi pivot adalah titik tengah transformasi (rotasi/translasi).
     */
    public static class BoneGroup {
        public final String name;
        public final String parent;   // null jika root
        public final float  px, py, pz; // pivot point
        public final float  rx, ry, rz; // rotasi default (derajat)
        public final List<Cube>      cubes    = new ArrayList<>();
        public final List<BoneGroup> children = new ArrayList<>();

        public BoneGroup(String name, String parent,
                         float px, float py, float pz,
                         float rx, float ry, float rz) {
            this.name   = name;
            this.parent = parent;
            this.px = px; this.py = py; this.pz = pz;
            this.rx = rx; this.ry = ry; this.rz = rz;
        }
    }

    /**
     * Muat model dari file JSON. Kembalikan root BoneGroup atau null jika gagal.
     */
    public static BoneGroup loadFromFile(Path jsonFile) {
        try (Reader r = Files.newBufferedReader(jsonFile)) {
            JsonObject root = JsonParser.parseReader(r).getAsJsonObject();
            return parseAnyFormat(root);
        } catch (Exception e) {
            return null;
        }
    }

    // ──────────────────────────────────────────────────────────────────────
    // Deteksi format dan parse
    // ──────────────────────────────────────────────────────────────────────
    private static BoneGroup parseAnyFormat(JsonObject root) {
        // Format Bedrock: {"format_version": ..., "minecraft:geometry": [...]}
        if (root.has("minecraft:geometry")) {
            return parseBedrockGeometry(root);
        }

        // Format YSM: {"meta":{"type":"ysm_model",...}, "bones":[...]}
        if (root.has("meta") && root.has("bones")) {
            return parseBoneArray(root.getAsJsonArray("bones"));
        }

        // Format sederhana / internal: {"name":"...", "bones":[...]}
        if (root.has("bones")) {
            return parseBoneArray(root.getAsJsonArray("bones"));
        }

        // Fallback: buat root bone default humanoid
        return buildDefaultHumanoidBones();
    }

    // ──────────────────────────────────────────────────────────────────────
    // Parse Bedrock geometry format
    // ──────────────────────────────────────────────────────────────────────
    private static BoneGroup parseBedrockGeometry(JsonObject root) {
        JsonArray geoList = root.getAsJsonArray("minecraft:geometry");
        if (geoList.isEmpty()) return buildDefaultHumanoidBones();
        JsonObject geo = geoList.get(0).getAsJsonObject();
        if (!geo.has("bones")) return buildDefaultHumanoidBones();
        return parseBoneArray(geo.getAsJsonArray("bones"));
    }

    // ──────────────────────────────────────────────────────────────────────
    // Parse array of bones, susun hierarki, kembalikan root
    // ──────────────────────────────────────────────────────────────────────
    private static BoneGroup parseBoneArray(JsonArray bonesArr) {
        // Pass 1: buat semua BoneGroup
        Map<String, BoneGroup> boneMap = new LinkedHashMap<>();
        for (JsonElement el : bonesArr) {
            if (!el.isJsonObject()) continue;
            JsonObject b = el.getAsJsonObject();

            String name   = getString(b, "name", "bone_" + boneMap.size());
            String parent = b.has("parent") ? b.get("parent").getAsString() : null;
            float[] pivot = getFloatArray(b, "pivot",   3, 0f);
            float[] rot   = getFloatArray(b, "rotation", 3, 0f);

            BoneGroup bone = new BoneGroup(
                name, parent,
                pivot[0], pivot[1], pivot[2],
                rot[0],   rot[1],   rot[2]
            );

            // Parse cubes
            if (b.has("cubes") && b.get("cubes").isJsonArray()) {
                for (JsonElement ce : b.getAsJsonArray("cubes")) {
                    if (!ce.isJsonObject()) continue;
                    Cube cube = parseCube(ce.getAsJsonObject());
                    if (cube != null) bone.cubes.add(cube);
                }
            }

            boneMap.put(name, bone);
        }

        // Pass 2: susun parent-child
        BoneGroup root = null;
        for (BoneGroup bone : boneMap.values()) {
            if (bone.parent != null && boneMap.containsKey(bone.parent)) {
                boneMap.get(bone.parent).children.add(bone);
            } else if (bone.parent == null) {
                // Ambil yang pertama tidak punya parent sebagai root
                if (root == null) root = bone;
            }
        }

        // Kalau tidak ada root eksplisit, buat wrapper root
        if (root == null) {
            BoneGroup wrapper = new BoneGroup("root", null, 0, 0, 0, 0, 0, 0);
            for (BoneGroup bone : boneMap.values()) {
                if (bone.parent == null) wrapper.children.add(bone);
            }
            root = wrapper;
        }

        return root;
    }

    private static Cube parseCube(JsonObject c) {
        try {
            float[] origin = getFloatArray(c, "origin", 3, 0f);
            float[] size   = getFloatArray(c, "size",   3, 0f);
            float u = 0, v = 0;

            // UV bisa berupa array [u, v] atau object per-face
            if (c.has("uv")) {
                JsonElement uvEl = c.get("uv");
                if (uvEl.isJsonArray()) {
                    JsonArray uvArr = uvEl.getAsJsonArray();
                    if (uvArr.size() >= 2) {
                        u = uvArr.get(0).getAsFloat();
                        v = uvArr.get(1).getAsFloat();
                    }
                }
                // per-face UV: gunakan UV dari face "north" sebagai representasi
                else if (uvEl.isJsonObject()) {
                    JsonObject uvObj = uvEl.getAsJsonObject();
                    for (String face : new String[]{"north", "up", "front"}) {
                        if (uvObj.has(face)) {
                            JsonObject faceObj = uvObj.getAsJsonObject(face);
                            if (faceObj.has("uv") && faceObj.get("uv").isJsonArray()) {
                                JsonArray arr = faceObj.getAsJsonArray("uv");
                                if (arr.size() >= 2) {
                                    u = arr.get(0).getAsFloat();
                                    v = arr.get(1).getAsFloat();
                                    break;
                                }
                            }
                        }
                    }
                }
            }

            float rot = 0f;
            if (c.has("rotation")) {
                JsonElement rotEl = c.get("rotation");
                if (rotEl.isJsonPrimitive()) rot = rotEl.getAsFloat();
            }

            return new Cube(origin[0], origin[1], origin[2],
                            size[0], size[1], size[2], u, v, rot);
        } catch (Exception e) {
            return null;
        }
    }

    // ──────────────────────────────────────────────────────────────────────
    // Fallback: humanoid default (mirip Steve)
    // ──────────────────────────────────────────────────────────────────────
    public static BoneGroup buildDefaultHumanoidBones() {
        BoneGroup root = new BoneGroup("root", null, 0, 0, 0, 0, 0, 0);

        // Kepala: pivot di atas leher (Y=24), cube 8x8x8
        BoneGroup head = new BoneGroup("head", "root", 0, 24, 0, 0, 0, 0);
        head.cubes.add(new Cube(-4, 0, -4, 8, 8, 8, 0, 0, 0));
        root.children.add(head);

        // Badan: pivot Y=24, cube 8x12x4
        BoneGroup body = new BoneGroup("body", "root", 0, 24, 0, 0, 0, 0);
        body.cubes.add(new Cube(-4, -12, -2, 8, 12, 4, 16, 16, 0));
        root.children.add(body);

        // Lengan kanan: pivot di bahu kanan
        BoneGroup rightArm = new BoneGroup("rightArm", "root", -5, 22, 0, 0, 0, 0);
        rightArm.cubes.add(new Cube(-3, -10, -2, 4, 12, 4, 40, 16, 0));
        root.children.add(rightArm);

        // Lengan kiri: pivot di bahu kiri
        BoneGroup leftArm = new BoneGroup("leftArm", "root", 5, 22, 0, 0, 0, 0);
        leftArm.cubes.add(new Cube(-1, -10, -2, 4, 12, 4, 32, 48, 0));
        root.children.add(leftArm);

        // Kaki kanan: pivot di pinggul kanan
        BoneGroup rightLeg = new BoneGroup("rightLeg", "root", -2, 12, 0, 0, 0, 0);
        rightLeg.cubes.add(new Cube(-2, -12, -2, 4, 12, 4, 0, 16, 0));
        root.children.add(rightLeg);

        // Kaki kiri: pivot di pinggul kiri
        BoneGroup leftLeg = new BoneGroup("leftLeg", "root", 2, 12, 0, 0, 0, 0);
        leftLeg.cubes.add(new Cube(-2, -12, -2, 4, 12, 4, 16, 48, 0));
        root.children.add(leftLeg);

        return root;
    }

    // ──────────────────────────────────────────────────────────────────────
    // Helper
    // ──────────────────────────────────────────────────────────────────────
    private static String getString(JsonObject obj, String key, String fallback) {
        return obj.has(key) ? obj.get(key).getAsString() : fallback;
    }

    private static float[] getFloatArray(JsonObject obj, String key, int len, float def) {
        float[] result = new float[len];
        Arrays.fill(result, def);
        if (!obj.has(key)) return result;
        JsonElement el = obj.get(key);
        if (el.isJsonArray()) {
            JsonArray arr = el.getAsJsonArray();
            for (int i = 0; i < Math.min(len, arr.size()); i++) {
                result[i] = arr.get(i).getAsFloat();
            }
        }
        return result;
    }
}
