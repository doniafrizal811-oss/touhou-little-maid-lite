package com.customplayermodel.client.model;

import com.customplayermodel.CustomPlayerModelMod;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.*;
import java.nio.file.*;
import java.util.*;

/**
 * Manajemen model custom player/maid.
 *
 * Desain ringan (cocok HP RAM 2GB):
 * - Lazy loading: model hanya dimuat saat pertama kali dipakai
 * - LRU cache max 10 model agar tidak makan RAM berlebihan
 * - Model disimpan di: .minecraft/config/customplayermodel/models/
 * - Mendukung format JSON: YSM, Bedrock Geometry, format sederhana
 *
 * Cara pakai model YSM:
 * 1. Taruh file .json model di folder config/customplayermodel/models/
 * 2. Taruh file texture di: assets/customplayermodel/textures/entity/<nama_model>/
 * 3. Buka menu dengan M (player) atau Shift+klik kanan maid
 */
public class CPMModelManager {

    private static CPMModelManager instance;

    // LRU Cache: max 10 model, yang paling lama tidak dipakai dibuang
    private final LinkedHashMap<String, CPMModelData> modelCache =
            new LinkedHashMap<>(16, 0.75f, true) {
                @Override
                protected boolean removeEldestEntry(Map.Entry<String, CPMModelData> e) {
                    return size() > 10;
                }
            };

    // Daftar model yang tersedia (modelId → displayName)
    private final Map<String, String> availableModels = new LinkedHashMap<>();

    private Path modelsDir;

    private CPMModelManager() {}

    public static CPMModelManager getInstance() {
        if (instance == null) instance = new CPMModelManager();
        return instance;
    }

    // ──────────────────────────────────────────────────────────────────────
    // Init: buat folder & scan model tersedia
    // ──────────────────────────────────────────────────────────────────────
    public void init() {
        modelsDir = net.fabricmc.loader.api.FabricLoader.getInstance()
                .getConfigDir()
                .resolve("customplayermodel/models");
        try {
            Files.createDirectories(modelsDir);
            CustomPlayerModelMod.LOGGER.info("[CPM] Folder model: {}", modelsDir);
            refreshAvailableModels();
        } catch (IOException e) {
            CustomPlayerModelMod.LOGGER.error("[CPM] Gagal buat folder model: {}", e.getMessage());
        }
    }

    // ──────────────────────────────────────────────────────────────────────
    // Scan ulang folder model
    // ──────────────────────────────────────────────────────────────────────
    public void refreshAvailableModels() {
        availableModels.clear();
        if (modelsDir == null) return;
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(modelsDir, "*.json")) {
            for (Path file : stream) {
                String fileName = file.getFileName().toString();
                String modelId  = fileName.replace(".json", "");
                String name     = readDisplayName(file, modelId);
                availableModels.put(modelId, name);
            }
        } catch (IOException e) {
            CustomPlayerModelMod.LOGGER.error("[CPM] Gagal scan folder: {}", e.getMessage());
        }
        CustomPlayerModelMod.LOGGER.info("[CPM] {} model tersedia.", availableModels.size());
    }

    private String readDisplayName(Path file, String fallback) {
        try (Reader r = Files.newBufferedReader(file)) {
            JsonObject obj = JsonParser.parseReader(r).getAsJsonObject();
            if (obj.has("name")) return obj.get("name").getAsString();
            // Format YSM: name ada di meta
            if (obj.has("meta") && obj.getAsJsonObject("meta").has("name")) {
                return obj.getAsJsonObject("meta").get("name").getAsString();
            }
        } catch (Exception ignored) {}
        return fallback;
    }

    // ──────────────────────────────────────────────────────────────────────
    // Muat model (lazy, dengan LRU cache)
    // ──────────────────────────────────────────────────────────────────────
    public Optional<CPMModelData> getModel(String modelId) {
        if (modelId == null || modelId.isBlank()) return Optional.empty();

        // Cache hit
        if (modelCache.containsKey(modelId)) {
            return Optional.of(modelCache.get(modelId));
        }

        // Lazy load dari file
        if (modelsDir == null) return Optional.empty();
        Path modelFile = modelsDir.resolve(modelId + ".json");
        if (!Files.exists(modelFile)) {
            CustomPlayerModelMod.LOGGER.warn("[CPM] Model tidak ada: {}.json", modelId);
            return Optional.empty();
        }

        try {
            CPMModelData data = parseModelFile(modelFile, modelId);
            modelCache.put(modelId, data);
            CustomPlayerModelMod.LOGGER.info("[CPM] Model dimuat: {}", modelId);
            return Optional.of(data);
        } catch (Exception e) {
            CustomPlayerModelMod.LOGGER.error("[CPM] Gagal muat model {}: {}", modelId, e.getMessage());
            return Optional.empty();
        }
    }

    // ──────────────────────────────────────────────────────────────────────
    // Parse satu file JSON model
    // ──────────────────────────────────────────────────────────────────────
    private CPMModelData parseModelFile(Path file, String modelId) throws IOException {
        try (Reader r = Files.newBufferedReader(file)) {
            JsonObject root = JsonParser.parseReader(r).getAsJsonObject();

            // Display name
            String displayName = availableModels.getOrDefault(modelId, modelId);

            // Texture file
            String texture = "";
            if (root.has("texture"))       texture = root.get("texture").getAsString();
            else if (root.has("textures") && root.get("textures").isJsonObject()) {
                JsonObject textures = root.getAsJsonObject("textures");
                if (textures.has("default")) texture = textures.get("default").getAsString();
                else if (textures.has("0"))  texture = textures.get("0").getAsString();
            }
            // Format YSM: texture di meta
            else if (root.has("meta") && root.getAsJsonObject("meta").has("texture")) {
                texture = root.getAsJsonObject("meta").get("texture").getAsString();
            }

            // Texture size
            int texW = 64, texH = 64;
            if (root.has("textureWidth"))  texW = root.get("textureWidth").getAsInt();
            if (root.has("textureHeight")) texH = root.get("textureHeight").getAsInt();
            // Bedrock geometry description
            if (root.has("minecraft:geometry")) {
                var geoArr = root.getAsJsonArray("minecraft:geometry");
                if (!geoArr.isEmpty()) {
                    var desc = geoArr.get(0).getAsJsonObject();
                    if (desc.has("description")) {
                        var d = desc.getAsJsonObject("description");
                        if (d.has("texture_width"))  texW = d.get("texture_width").getAsInt();
                        if (d.has("texture_height")) texH = d.get("texture_height").getAsInt();
                    }
                }
            }

            // Parse bone hierarki dari file
            YsmModelLoader.BoneGroup rootBone = YsmModelLoader.loadFromFile(file);

            return new CPMModelData(modelId, displayName, texture, texW, texH, rootBone);
        }
    }

    // ──────────────────────────────────────────────────────────────────────
    // Public getters
    // ──────────────────────────────────────────────────────────────────────
    public Map<String, String> getAvailableModels() {
        return Collections.unmodifiableMap(availableModels);
    }

    public void clearAll() {
        modelCache.clear();
        availableModels.clear();
    }
}
