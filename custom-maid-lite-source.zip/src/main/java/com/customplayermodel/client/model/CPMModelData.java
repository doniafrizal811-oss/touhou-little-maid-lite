package com.customplayermodel.client.model;

import net.minecraft.util.Identifier;

/**
 * Data model yang sudah diparse dari JSON (YSM atau format sederhana).
 * Hanya menyimpan metadata + data geometri ringan.
 * Tidak menyimpan texture image (diload GL saat render).
 */
public class CPMModelData {
    private final String  modelId;
    private final String  displayName;
    private final String  textureFile;  // nama file texture (relatif ke textures/entity/<modelId>/)
    private final int     textureWidth;
    private final int     textureHeight;
    private final YsmModelLoader.BoneGroup rootBone; // hierarki bone dari YSM

    public CPMModelData(String modelId, String displayName, String textureFile,
                        int textureWidth, int textureHeight,
                        YsmModelLoader.BoneGroup rootBone) {
        this.modelId       = modelId;
        this.displayName   = displayName;
        this.textureFile   = textureFile;
        this.textureWidth  = textureWidth;
        this.textureHeight = textureHeight;
        this.rootBone      = rootBone;
    }

    public String getModelId()      { return modelId; }
    public String getDisplayName()  { return displayName; }
    public String getTextureFile()  { return textureFile; }
    public int    getTextureWidth() { return textureWidth; }
    public int    getTextureHeight(){ return textureHeight; }
    public YsmModelLoader.BoneGroup getRootBone() { return rootBone; }

    public boolean hasCustomBones()  { return rootBone != null; }

    /**
     * Identifier untuk texture OpenGL.
     * Path: assets/customplayermodel/textures/entity/<modelId>/<textureFile>
     */
    public Identifier getTextureIdentifier() {
        String path = textureFile.isBlank()
            ? "textures/entity/maid/default.png"
            : "textures/entity/" + modelId + "/" + textureFile;
        return new Identifier("customplayermodel", path);
    }

    @Override
    public String toString() {
        return "CPMModelData{id=" + modelId + ", name=" + displayName
            + ", tex=" + textureFile + "}";
    }
}
