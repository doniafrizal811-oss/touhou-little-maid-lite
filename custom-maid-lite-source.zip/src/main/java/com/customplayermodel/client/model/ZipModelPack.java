package com.customplayermodel.client.model;

import com.customplayermodel.CustomPlayerModelMod;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

/**
 * Loader untuk pack model YSM plain (format zip, tidak terenkripsi).
 *
 * Struktur pack yang didukung (mengikuti Yes Steve Model open format):
 *   ├── ysm.json                (metadata + pointer entry: "model": "models/main.json")
 *   ├── models/main.json        (bedrock geometry: minecraft:geometry/bones/cubes)
 *   ├── textures/texture.png    (texture utama)
 *   └── animations/*.json       (opsional, geckolib format — belum dieksekusi)
 *
 * Fallback: kalau ysm.json tidak ada, coba cari models/main.json langsung, dan
 * texture pertama di textures/*.png.
 *
 * CATATAN: file .ysm terenkripsi (format 9 crypto 3) TIDAK didukung.
 * Format tersebut proprietary Yes Steve Model dan butuh kunci internal.
 * Gunakan pack ZIP unencrypted (seperti ameyumi_omo_v1.0.1.zip).
 */
public class ZipModelPack {

    public final String modelId;
    public final String displayName;
    public final YsmModelLoader.BoneGroup rootBone;
    public final byte[] textureBytes;      // raw PNG bytes; null jika tidak ada
    public final String textureFileName;   // untuk registrasi Identifier
    public final int textureWidth;
    public final int textureHeight;

    private ZipModelPack(String modelId, String displayName,
                         YsmModelLoader.BoneGroup rootBone,
                         byte[] textureBytes, String textureFileName,
                         int tw, int th) {
        this.modelId = modelId;
        this.displayName = displayName;
        this.rootBone = rootBone;
        this.textureBytes = textureBytes;
        this.textureFileName = textureFileName;
        this.textureWidth = tw;
        this.textureHeight = th;
    }

    /** Load pack dari file zip. Kembalikan null jika gagal. */
    public static ZipModelPack loadZip(Path zipFile, String modelId) {
        Map<String, byte[]> entries = readAllEntries(zipFile);
        if (entries.isEmpty()) return null;
        return buildFromEntries(entries, modelId);
    }

    /** Load pack dari folder (extracted zip). */
    public static ZipModelPack loadDirectory(Path dir, String modelId) {
        Map<String, byte[]> entries = new HashMap<>();
        try {
            Files.walk(dir).filter(Files::isRegularFile).forEach(p -> {
                try {
                    String rel = dir.relativize(p).toString().replace('\\', '/');
                    entries.put(rel, Files.readAllBytes(p));
                } catch (IOException ignored) {}
            });
        } catch (IOException e) {
            return null;
        }
        return buildFromEntries(entries, modelId);
    }

    private static Map<String, byte[]> readAllEntries(Path zip) {
        Map<String, byte[]> out = new HashMap<>();
        try (ZipInputStream zin = new ZipInputStream(
                new BufferedInputStream(Files.newInputStream(zip)))) {
            ZipEntry e;
            byte[] buf = new byte[8192];
            while ((e = zin.getNextEntry()) != null) {
                if (e.isDirectory()) continue;
                // Batasi ukuran per-entry: 10 MB (aman untuk HP RAM 2GB)
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                int n; int total = 0;
                while ((n = zin.read(buf)) > 0) {
                    total += n;
                    if (total > 10 * 1024 * 1024) {
                        CustomPlayerModelMod.LOGGER.warn(
                            "[CPM] Skip entry >10MB: {}", e.getName());
                        bos.reset(); break;
                    }
                    bos.write(buf, 0, n);
                }
                if (bos.size() > 0) out.put(e.getName().replace('\\', '/'), bos.toByteArray());
            }
        } catch (IOException ex) {
            CustomPlayerModelMod.LOGGER.error("[CPM] Gagal buka zip {}: {}",
                    zip, ex.getMessage());
        }
        return out;
    }

    private static ZipModelPack buildFromEntries(Map<String, byte[]> entries, String modelId) {
        // 1. Cari & baca ysm.json
        String displayName = modelId;
        String modelPath = null;
        String texturePathHint = null;

        byte[] ysmJson = findEntry(entries, "ysm.json");
        if (ysmJson != null) {
            try {
                JsonObject meta = JsonParser.parseString(new String(ysmJson))
                        .getAsJsonObject();
                if (meta.has("name")) displayName = meta.get("name").getAsString();
                if (meta.has("model")) modelPath = meta.get("model").getAsString();
                if (meta.has("texture")) texturePathHint = meta.get("texture").getAsString();
            } catch (Exception ignored) {}
        }

        // 2. Fallback path model
        if (modelPath == null || findEntry(entries, modelPath) == null) {
            for (String cand : new String[]{"models/main.json","model.json",
                    "main.json","models/model.json"}) {
                if (findEntry(entries, cand) != null) { modelPath = cand; break; }
            }
        }
        if (modelPath == null) {
            // ambil json pertama yang ada "bones" atau "minecraft:geometry"
            for (Map.Entry<String,byte[]> e : entries.entrySet()) {
                if (!e.getKey().toLowerCase().endsWith(".json")) continue;
                String s = new String(e.getValue());
                if (s.contains("\"bones\"") || s.contains("minecraft:geometry")) {
                    modelPath = e.getKey(); break;
                }
            }
        }
        if (modelPath == null) {
            CustomPlayerModelMod.LOGGER.warn("[CPM] Pack {} tidak berisi model json.", modelId);
            return null;
        }

        // 3. Parse geometri
        YsmModelLoader.BoneGroup root;
        int texW = 64, texH = 64;
        byte[] modelBytes = findEntry(entries, modelPath);
        try {
            JsonObject json = JsonParser.parseString(new String(modelBytes)).getAsJsonObject();
            root = parseGeometry(modelBytes);
            // ambil texture size dari bedrock geometry
            if (json.has("minecraft:geometry")) {
                var arr = json.getAsJsonArray("minecraft:geometry");
                if (arr.size() > 0) {
                    var desc = arr.get(0).getAsJsonObject();
                    if (desc.has("description")) {
                        var d = desc.getAsJsonObject("description");
                        if (d.has("texture_width"))  texW = d.get("texture_width").getAsInt();
                        if (d.has("texture_height")) texH = d.get("texture_height").getAsInt();
                    }
                }
            }
        } catch (Exception e) {
            CustomPlayerModelMod.LOGGER.error("[CPM] Gagal parse {}: {}",
                    modelPath, e.getMessage());
            return null;
        }

        // 4. Cari texture utama
        byte[] texture = null;
        String textureName = null;
        if (texturePathHint != null) {
            texture = findEntry(entries, texturePathHint);
            textureName = texturePathHint;
        }
        if (texture == null) {
            for (String cand : new String[]{"textures/texture.png","textures/main.png",
                    "texture.png","textures/skin.png"}) {
                texture = findEntry(entries, cand);
                if (texture != null) { textureName = cand; break; }
            }
        }
        if (texture == null) {
            // png pertama yang ditemukan (skip yang di avatar/ atau _A alpha map)
            for (Map.Entry<String,byte[]> e : entries.entrySet()) {
                String k = e.getKey().toLowerCase();
                if (k.endsWith(".png") && !k.startsWith("avatar/")
                        && !k.contains("_a.") && !k.contains("_alpha")) {
                    texture = e.getValue();
                    textureName = e.getKey();
                    break;
                }
            }
        }

        return new ZipModelPack(modelId, displayName, root,
                texture, textureName, texW, texH);
    }

    /** Case-insensitive entry lookup. */
    private static byte[] findEntry(Map<String, byte[]> entries, String path) {
        if (entries.containsKey(path)) return entries.get(path);
        for (Map.Entry<String,byte[]> e : entries.entrySet()) {
            if (e.getKey().equalsIgnoreCase(path)) return e.getValue();
        }
        return null;
    }

    /** Parse geometri via YsmModelLoader (tulis ke temp file lalu load). */
    private static YsmModelLoader.BoneGroup parseGeometry(byte[] bytes) {
        try {
            Path tmp = Files.createTempFile("cpm_model_", ".json");
            Files.write(tmp, bytes);
            YsmModelLoader.BoneGroup g = YsmModelLoader.loadFromFile(tmp);
            try { Files.deleteIfExists(tmp); } catch (IOException ignored) {}
            return g != null ? g : YsmModelLoader.buildDefaultHumanoidBones();
        } catch (IOException e) {
            return YsmModelLoader.buildDefaultHumanoidBones();
        }
    }
}
