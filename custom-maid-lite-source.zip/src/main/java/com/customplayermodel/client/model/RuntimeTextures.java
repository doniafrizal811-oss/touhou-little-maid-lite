package com.customplayermodel.client.model;

import com.customplayermodel.CustomPlayerModelMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import java.io.ByteArrayInputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Registrasi texture PNG dari file eksternal (mis. dalam zip pack di folder config)
 * ke TextureManager Minecraft agar bisa dipakai renderer.
 *
 * Semua texture di-cache; register ulang → reuse Identifier lama.
 * Path Identifier: customplayermodel:dyn/<key>
 */
public final class RuntimeTextures {

    private static final Map<String, Identifier> CACHE = new HashMap<>();

    private RuntimeTextures() {}

    /**
     * Register raw PNG bytes sebagai texture, kembalikan Identifier.
     * @param key  identitas unik (mis. modelId + "/" + filename)
     * @param png  raw bytes file PNG
     */
    public static Identifier register(String key, byte[] png) {
        Identifier existing = CACHE.get(key);
        if (existing != null) return existing;

        try {
            NativeImage img = NativeImage.read(new ByteArrayInputStream(png));
            NativeImageBackedTexture tex = new NativeImageBackedTexture(img);
            // Sanitize key → hanya karakter valid untuk Identifier path
            String safe = key.toLowerCase()
                    .replaceAll("[^a-z0-9/._-]", "_");
            Identifier id = new Identifier(CustomPlayerModelMod.MOD_ID, "dyn/" + safe);
            MinecraftClient.getInstance().getTextureManager().registerTexture(id, tex);
            CACHE.put(key, id);
            CustomPlayerModelMod.LOGGER.info("[CPM] Runtime texture: {} ({}x{})",
                    id, img.getWidth(), img.getHeight());
            return id;
        } catch (Exception e) {
            CustomPlayerModelMod.LOGGER.error("[CPM] Gagal register texture {}: {}",
                    key, e.getMessage());
            return new Identifier(CustomPlayerModelMod.MOD_ID,
                    "textures/entity/maid/default.png");
        }
    }

    public static void clear() { CACHE.clear(); }
}
