package com.customplayermodel.client.renderer;

import com.customplayermodel.client.model.CPMModelData;
import com.customplayermodel.client.model.YsmModelLoader;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix4f;

/**
 * Renderer untuk player dengan model YSM custom.
 * Dipanggil dari PlayerEntityRendererMixin saat player punya custom model.
 *
 * Untuk 1.20.1: menggunakan MatrixStack + VertexConsumer manual (tanpa GeckoLib).
 */
public class CPMPlayerRenderer {

    private static final float PIXEL = 1f / 16f;

    /**
     * Render player dengan custom YSM model.
     * @param player        Player yang dirender
     * @param modelData     Data model YSM sudah diparse
     * @param yaw           Entity yaw
     * @param tickDelta     Tick delta interpolasi
     * @param matrices      MatrixStack
     * @param vertexConsumers Buffer render
     * @param light         Light value
     */
    public static void render(AbstractClientPlayerEntity player, CPMModelData modelData,
                              float yaw, float tickDelta, MatrixStack matrices,
                              VertexConsumerProvider vertexConsumers, int light) {
        if (modelData == null || modelData.getRootBone() == null) return;

        matrices.push();

        // Rotasi menghadap ke depan
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180f - yaw));
        matrices.translate(0, -1.5 * PIXEL * 16, 0);

        Identifier texture = modelData.getTextureIdentifier();
        VertexConsumer vc = vertexConsumers.getBuffer(RenderLayer.getEntitySolid(texture));

        float limbAngle    = player.limbAnimator.getPos(tickDelta);
        float limbDistance = player.limbAnimator.getSpeed(tickDelta);
        float animProgress = (float) player.age + tickDelta;

        renderBone(modelData.getRootBone(), player, matrices, vc, light,
                   modelData.getTextureWidth(), modelData.getTextureHeight(),
                   limbAngle, limbDistance, animProgress, yaw, tickDelta);

        matrices.pop();
    }

    // ──────────────────────────────────────────────────────────────────────
    // Render bone rekursif
    // ──────────────────────────────────────────────────────────────────────
    private static void renderBone(YsmModelLoader.BoneGroup bone, AbstractClientPlayerEntity player,
                                   MatrixStack matrices, VertexConsumer vc, int light,
                                   int texW, int texH,
                                   float limbAngle, float limbDist, float animProgress,
                                   float yaw, float tickDelta) {
        matrices.push();

        matrices.translate(bone.px * PIXEL, bone.py * PIXEL, bone.pz * PIXEL);
        if (bone.rx != 0) matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(bone.rx));
        if (bone.ry != 0) matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(bone.ry));
        if (bone.rz != 0) matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(bone.rz));

        // Animasi tulang player
        applyPlayerBoneAnimation(bone.name, player, matrices, limbAngle, limbDist, animProgress, yaw, tickDelta);

        Matrix4f mat = matrices.peek().getPositionMatrix();
        for (YsmModelLoader.Cube cube : bone.cubes) {
            renderCube(cube, mat, vc, light, texW, texH);
        }

        for (YsmModelLoader.BoneGroup child : bone.children) {
            matrices.translate(-bone.px * PIXEL, -bone.py * PIXEL, -bone.pz * PIXEL);
            renderBone(child, player, matrices, vc, light, texW, texH,
                       limbAngle, limbDist, animProgress, yaw, tickDelta);
            matrices.translate(bone.px * PIXEL, bone.py * PIXEL, bone.pz * PIXEL);
        }

        matrices.pop();
    }

    private static void applyPlayerBoneAnimation(String boneName, AbstractClientPlayerEntity player,
                                                  MatrixStack matrices,
                                                  float limbAngle, float limbDist, float animProgress,
                                                  float yaw, float tickDelta) {
        String n = boneName.toLowerCase();

        if (n.contains("head")) {
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(player.headYaw - player.bodyYaw));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(player.getPitch(tickDelta) * 0.5f));

        } else if (n.contains("rightarm") || n.equals("arm_r") || n.equals("right_arm")) {
            float swing = MathHelper.cos(limbAngle * 0.6662f + (float) Math.PI) * 0.7f * limbDist;
            if (limbDist < 0.01f) swing = -MathHelper.sin(animProgress * 0.05f) * 0.04f;
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float) Math.toDegrees(swing)));

        } else if (n.contains("leftarm") || n.equals("arm_l") || n.equals("left_arm")) {
            float swing = MathHelper.cos(limbAngle * 0.6662f) * 0.7f * limbDist;
            if (limbDist < 0.01f) swing = MathHelper.sin(animProgress * 0.05f) * 0.04f;
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float) Math.toDegrees(swing)));

        } else if (n.contains("rightleg") || n.equals("leg_r") || n.equals("right_leg")) {
            float swing = MathHelper.cos(limbAngle * 0.6662f) * 1.0f * limbDist;
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float) Math.toDegrees(swing)));

        } else if (n.contains("leftleg") || n.equals("leg_l") || n.equals("left_leg")) {
            float swing = MathHelper.cos(limbAngle * 0.6662f + (float) Math.PI) * 1.0f * limbDist;
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float) Math.toDegrees(swing)));
        }
    }

    // ──────────────────────────────────────────────────────────────────────
    // Cube & quad render (sama seperti MaidEntityRenderer)
    // ──────────────────────────────────────────────────────────────────────
    private static void renderCube(YsmModelLoader.Cube c, Matrix4f mat, VertexConsumer vc,
                                   int light, int texW, int texH) {
        float x0 = c.ox * PIXEL, y0 = c.oy * PIXEL, z0 = c.oz * PIXEL;
        float x1 = (c.ox + c.sx) * PIXEL;
        float y1 = (c.oy + c.sy) * PIXEL;
        float z1 = (c.oz + c.sz) * PIXEL;
        float sx = c.sx, sy = c.sy, sz = c.sz;
        float u0 = c.u, v0 = c.v;
        float tw = texW, th = texH;

        quad(mat,vc,light, x0,y1,z1, x1,y1,z1, x1,y0,z1, x0,y0,z1,
             (u0+sz)/tw,(v0+sz)/th,(u0+sz+sx)/tw,(v0+sz+sy)/th, 0,0,1);
        quad(mat,vc,light, x1,y1,z0, x0,y1,z0, x0,y0,z0, x1,y0,z0,
             (u0+sz+sx+sz)/tw,(v0+sz)/th,(u0+sz+sx+sz+sx)/tw,(v0+sz+sy)/th, 0,0,-1);
        quad(mat,vc,light, x0,y1,z0, x1,y1,z0, x1,y1,z1, x0,y1,z1,
             (u0+sz)/tw,v0/th,(u0+sz+sx)/tw,(v0+sz)/th, 0,1,0);
        quad(mat,vc,light, x0,y0,z1, x1,y0,z1, x1,y0,z0, x0,y0,z0,
             (u0+sz+sx)/tw,v0/th,(u0+sz+sx+sx)/tw,(v0+sz)/th, 0,-1,0);
        quad(mat,vc,light, x0,y1,z0, x0,y1,z1, x0,y0,z1, x0,y0,z0,
             u0/tw,(v0+sz)/th,(u0+sz)/tw,(v0+sz+sy)/th, -1,0,0);
        quad(mat,vc,light, x1,y1,z1, x1,y1,z0, x1,y0,z0, x1,y0,z1,
             (u0+sz+sx)/tw,(v0+sz)/th,(u0+sz+sx+sz)/tw,(v0+sz+sy)/th, 1,0,0);
    }

    private static void quad(Matrix4f mat, VertexConsumer vc, int light,
                             float x0,float y0,float z0, float x1,float y1,float z1,
                             float x2,float y2,float z2, float x3,float y3,float z3,
                             float u0,float v0,float u1,float v1,
                             float nx,float ny,float nz) {
        int ov = net.minecraft.client.render.OverlayTexture.DEFAULT_UV;
        vc.vertex(mat,x0,y0,z0).color(1f,1f,1f,1f).texture(u0,v1).overlay(ov).light(light).normal(nx,ny,nz).next();
        vc.vertex(mat,x1,y1,z1).color(1f,1f,1f,1f).texture(u1,v1).overlay(ov).light(light).normal(nx,ny,nz).next();
        vc.vertex(mat,x2,y2,z2).color(1f,1f,1f,1f).texture(u1,v0).overlay(ov).light(light).normal(nx,ny,nz).next();
        vc.vertex(mat,x3,y3,z3).color(1f,1f,1f,1f).texture(u0,v0).overlay(ov).light(light).normal(nx,ny,nz).next();
    }
}
