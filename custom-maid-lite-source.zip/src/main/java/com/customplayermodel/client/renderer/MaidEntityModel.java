package com.customplayermodel.client.renderer;

import com.customplayermodel.entity.MaidEntity;
import net.minecraft.client.model.*;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

/**
 * Model fallback default untuk maid (mirip humanoid).
 * Digunakan saat tidak ada model YSM custom.
 * Kompatibel 1.20.1 Fabric.
 */
public class MaidEntityModel extends net.minecraft.client.render.entity.model.EntityModel<MaidEntity> {

    public static final EntityModelLayer LAYER_LOCATION =
        new EntityModelLayer(
            new Identifier("customplayermodel", "maid"),
            "main"
        );

    // Parts model
    private final ModelPart head;
    private final ModelPart hair;
    private final ModelPart body;
    private final ModelPart rightArm;
    private final ModelPart leftArm;
    private final ModelPart rightLeg;
    private final ModelPart leftLeg;

    public MaidEntityModel(ModelPart root) {
        this.head     = root.getChild("head");
        this.hair     = root.getChild("hair");
        this.body     = root.getChild("body");
        this.rightArm = root.getChild("right_arm");
        this.leftArm  = root.getChild("left_arm");
        this.rightLeg = root.getChild("right_leg");
        this.leftLeg  = root.getChild("left_leg");
    }

    /**
     * Buat data model dengan cuboid yang kompatibel 1.20.1.
     */
    public static TexturedModelData getTexturedModelData() {
        ModelData modelData = new ModelData();
        ModelPartData root  = modelData.getRoot();

        // Kepala
        root.addChild("head",
            ModelPartBuilder.create()
                .uv(0, 0).cuboid(-4f, -8f, -4f, 8, 8, 8),
            ModelTransform.pivot(0f, 0f, 0f)
        );

        // Rambut (layer luar kepala, sedikit lebih besar)
        root.addChild("hair",
            ModelPartBuilder.create()
                .uv(32, 0).cuboid(-4.5f, -8.5f, -4.5f, 9, 9, 9),
            ModelTransform.pivot(0f, 0f, 0f)
        );

        // Badan
        root.addChild("body",
            ModelPartBuilder.create()
                .uv(16, 16).cuboid(-4f, 0f, -2f, 8, 12, 4),
            ModelTransform.pivot(0f, 0f, 0f)
        );

        // Lengan kanan (pivot di bahu)
        root.addChild("right_arm",
            ModelPartBuilder.create()
                .uv(40, 16).cuboid(-3f, -2f, -2f, 4, 12, 4),
            ModelTransform.pivot(-5f, 2f, 0f)
        );

        // Lengan kiri (pivot di bahu)
        root.addChild("left_arm",
            ModelPartBuilder.create()
                .uv(32, 48).cuboid(-1f, -2f, -2f, 4, 12, 4),
            ModelTransform.pivot(5f, 2f, 0f)
        );

        // Kaki kanan
        root.addChild("right_leg",
            ModelPartBuilder.create()
                .uv(0, 16).cuboid(-2f, 0f, -2f, 4, 12, 4),
            ModelTransform.pivot(-2f, 12f, 0f)
        );

        // Kaki kiri
        root.addChild("left_leg",
            ModelPartBuilder.create()
                .uv(16, 48).cuboid(-2f, 0f, -2f, 4, 12, 4),
            ModelTransform.pivot(2f, 12f, 0f)
        );

        return TexturedModelData.of(modelData, 64, 64);
    }

    // ──────────────────────────────────────────────────────────────────────
    // Animasi
    // ──────────────────────────────────────────────────────────────────────
    @Override
    public void setAngles(MaidEntity entity, float limbAngle, float limbDistance,
                          float animProgress, float headYaw, float headPitch) {
        // Reset
        head.yaw   = 0; head.pitch = 0; head.roll = 0;
        hair.yaw   = 0; hair.pitch = 0;
        body.yaw   = 0; body.pitch = 0;
        rightArm.yaw = 0; rightArm.pitch = 0;
        leftArm.yaw  = 0; leftArm.pitch  = 0;
        rightLeg.yaw = 0; rightLeg.pitch = 0;
        leftLeg.yaw  = 0; leftLeg.pitch  = 0;

        // Kepala mengikuti pandangan
        head.yaw   = headYaw   * ((float) Math.PI / 180f);
        head.pitch = headPitch * ((float) Math.PI / 180f);
        hair.yaw   = head.yaw;
        hair.pitch = head.pitch;

        boolean sitting = entity.isInSittingPose();
        boolean carried = entity.isBeingCarried();

        if (sitting) {
            // Pose duduk: kaki ditekuk
            rightLeg.pitch = -(float) Math.PI / 4f;
            leftLeg.pitch  = -(float) Math.PI / 4f;
            rightLeg.yaw   =  (float) Math.PI / 8f;
            leftLeg.yaw    = -(float) Math.PI / 8f;
            // Tangan di depan
            rightArm.pitch = -(float) Math.PI / 8f;
            leftArm.pitch  = -(float) Math.PI / 8f;

        } else if (carried) {
            // Pose digendong: tangan memeluk carrier
            rightArm.pitch = -(float) Math.PI / 3f;
            leftArm.pitch  = -(float) Math.PI / 3f;
            rightArm.roll  = -(float) Math.PI / 8f;
            leftArm.roll   =  (float) Math.PI / 8f;
            // Kaki menggantung
            rightLeg.pitch = (float) Math.PI / 6f;
            leftLeg.pitch  = (float) Math.PI / 6f;

        } else {
            // Berjalan / diam
            rightLeg.pitch = MathHelper.cos(limbAngle * 0.6662f) * 1.0f * limbDistance;
            leftLeg.pitch  = MathHelper.cos(limbAngle * 0.6662f + (float) Math.PI) * 1.0f * limbDistance;
            rightArm.pitch = MathHelper.cos(limbAngle * 0.6662f + (float) Math.PI) * 0.7f * limbDistance;
            leftArm.pitch  = MathHelper.cos(limbAngle * 0.6662f) * 0.7f * limbDistance;

            // Animasi idle: tangan goyang pelan saat diam
            if (limbDistance < 0.01f) {
                float idleSwing = MathHelper.sin(animProgress * 0.05f) * 0.04f;
                leftArm.pitch  =  idleSwing;
                rightArm.pitch = -idleSwing;
            }
        }
    }

    // ──────────────────────────────────────────────────────────────────────
    // Render semua parts
    // ──────────────────────────────────────────────────────────────────────
    @Override
    public void render(MatrixStack matrices, VertexConsumer vertexConsumer,
                       int light, int overlay, float r, float g, float b, float a) {
        head.render(matrices, vertexConsumer, light, overlay, r, g, b, a);
        hair.render(matrices, vertexConsumer, light, overlay, r, g, b, a);
        body.render(matrices, vertexConsumer, light, overlay, r, g, b, a);
        rightArm.render(matrices, vertexConsumer, light, overlay, r, g, b, a);
        leftArm.render(matrices, vertexConsumer, light, overlay, r, g, b, a);
        rightLeg.render(matrices, vertexConsumer, light, overlay, r, g, b, a);
        leftLeg.render(matrices, vertexConsumer, light, overlay, r, g, b, a);
    }
}
