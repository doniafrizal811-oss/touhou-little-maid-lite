package com.customplayermodel.client.renderer;

import com.customplayermodel.client.model.CPMModelData;
import com.customplayermodel.client.model.CPMModelManager;
import com.customplayermodel.client.model.YsmModelLoader;
import com.customplayermodel.entity.MaidEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix4f;

import java.util.Optional;

/**
 * Renderer untuk MaidEntity.
 *
 * Logika render:
 * 1. Jika maid punya modelId valid → render bones dari YSM
 * 2. Jika tidak ada / gagal → render fallback MaidEntityModel (humanoid default)
 *
 * Optimasi:
 * - Tidak simpan state per entity di renderer
 * - Lazy load via CPMModelManager (LRU cache max 10)
 * - Saat digendong: scale lebih kecil agar kelihatan di bahu
 */
public class MaidEntityRenderer extends MobEntityRenderer<MaidEntity, MaidEntityModel> {

    private static final Identifier FALLBACK_TEXTURE =
        new Identifier("customplayermodel", "textures/entity/maid/default.png");

    // Ukuran 1 pixel dalam unit model (Minecraft: 16px = 1 blok)
    private static final float PIXEL = 1f / 16f;

    public MaidEntityRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new MaidEntityModel(ctx.getPart(MaidEntityModel.LAYER_LOCATION)), 0.3f);
    }

    // ──────────────────────────────────────────────────────────────────────
    // Texture
    // ──────────────────────────────────────────────────────────────────────
    @Override
    public Identifier getTexture(MaidEntity entity) {
        String modelId = entity.getModelId();
        if (!modelId.isBlank()) {
            Optional<CPMModelData> data = CPMModelManager.getInstance().getModel(modelId);
            if (data.isPresent() && !data.get().getTextureFile().isBlank()) {
                return data.get().getTextureIdentifier();
            }
        }
        return FALLBACK_TEXTURE;
    }

    // ──────────────────────────────────────────────────────────────────────
    // Render utama
    // ──────────────────────────────────────────────────────────────────────
    @Override
    public void render(MaidEntity entity, float yaw, float tickDelta,
                       MatrixStack matrices, VertexConsumerProvider vertexConsumers,
                       int light) {
        matrices.push();

        // Saat digendong: skalakan kecil agar muat di bahu
        float scale = entity.isBeingCarried() ? 0.45f : 0.9f;
        matrices.scale(scale, scale, scale);

        // Pose duduk: turunkan sedikit
        if (entity.isInSittingPose() && !entity.isBeingCarried()) {
            matrices.translate(0, -0.35, 0);
        }

        // Coba render model YSM custom
        String modelId = entity.getModelId();
        if (!modelId.isBlank()) {
            Optional<CPMModelData> modelData = CPMModelManager.getInstance().getModel(modelId);
            if (modelData.isPresent() && modelData.get().hasCustomBones()) {
                renderYsmModel(entity, modelData.get(), yaw, tickDelta,
                        matrices, vertexConsumers, light);
                matrices.pop();
                return;
            }
        }

        // Fallback: render default humanoid
        super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
        matrices.pop();
    }

    // ──────────────────────────────────────────────────────────────────────
    // Render YSM model (bone-based, rekursif)
    // ──────────────────────────────────────────────────────────────────────
    private void renderYsmModel(MaidEntity entity, CPMModelData modelData,
                                float yaw, float tickDelta, MatrixStack matrices,
                                VertexConsumerProvider vertexConsumers, int light) {
        matrices.push();
        // Rotasi entity sesuai arah hadap
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180f - yaw));
        // Geser ke tengah entitas
        matrices.translate(0, -1.5 * PIXEL * 16, 0);

        Identifier texture = modelData.getTextureIdentifier();
        VertexConsumer vc = vertexConsumers.getBuffer(RenderLayer.getEntitySolid(texture));

        YsmModelLoader.BoneGroup root = modelData.getRootBone();
        if (root != null) {
            // Hitung animasi berdasarkan state entity
            float limbAngle    = entity.limbAnimator.getPos(tickDelta);
            float limbDistance = entity.limbAnimator.getSpeed(tickDelta);
            float animProgress = entity.age + tickDelta;

            renderBone(root, entity, matrices, vc, light,
                       modelData.getTextureWidth(), modelData.getTextureHeight(),
                       limbAngle, limbDistance, animProgress, yaw, tickDelta);
        }
        matrices.pop();
    }

    /**
     * Render satu BoneGroup beserta semua anaknya (rekursif).
     * Pivot point = pusat transformasi tulang.
     */
    private void renderBone(YsmModelLoader.BoneGroup bone, MaidEntity entity,
                            MatrixStack matrices, VertexConsumer vc, int light,
                            int texW, int texH,
                            float limbAngle, float limbDist, float animProgress,
                            float yaw, float tickDelta) {
        matrices.push();

        // Translasi ke pivot
        matrices.translate(
            bone.px * PIXEL,
            bone.py * PIXEL,
            bone.pz * PIXEL
        );

        // Rotasi default tulang
        if (bone.rx != 0) matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(bone.rx));
        if (bone.ry != 0) matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(bone.ry));
        if (bone.rz != 0) matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(bone.rz));

        // Rotasi animasi berdasarkan nama tulang
        applyBoneAnimation(bone.name, entity, matrices, limbAngle, limbDist, animProgress, yaw, tickDelta);

        // Render semua cube di tulang ini
        Matrix4f mat = matrices.peek().getPositionMatrix();
        for (YsmModelLoader.Cube cube : bone.cubes) {
            renderCube(cube, mat, vc, light, texW, texH);
        }

        // Render anak tulang (rekursif)
        for (YsmModelLoader.BoneGroup child : bone.children) {
            // Balik translasi pivot agar anak dihitung dari origin
            matrices.translate(-bone.px * PIXEL, -bone.py * PIXEL, -bone.pz * PIXEL);
            renderBone(child, entity, matrices, vc, light, texW, texH,
                       limbAngle, limbDist, animProgress, yaw, tickDelta);
            matrices.translate(bone.px * PIXEL, bone.py * PIXEL, bone.pz * PIXEL);
        }

        matrices.pop();
    }

    /**
     * Terapkan rotasi animasi berdasarkan nama tulang (standar humanoid).
     * Mendukung nama bone standar YSM: head, body, rightArm, leftArm, rightLeg, leftLeg, dll.
     */
    private void applyBoneAnimation(String boneName, MaidEntity entity, MatrixStack matrices,
                                    float limbAngle, float limbDist, float animProgress,
                                    float yaw, float tickDelta) {
        boolean sitting = entity.isInSittingPose();
        boolean carried = entity.isBeingCarried();
        String n = boneName.toLowerCase();

        if (n.contains("head")) {
            // Kepala mengikuti pandangan player (simulasi: pakai yaw)
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(entity.headYaw - entity.bodyYaw));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(entity.getPitch() * 0.5f));

        } else if (n.contains("rightarm") || n.equals("arm_r") || n.equals("right_arm")) {
            if (sitting) {
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-22.5f));
            } else if (carried) {
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-60f));
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-22.5f));
            } else {
                float swing = MathHelper.cos(limbAngle * 0.6662f + (float) Math.PI) * 0.7f * limbDist;
                if (limbDist < 0.01f) swing = -MathHelper.sin(animProgress * 0.05f) * 0.04f;
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float) Math.toDegrees(swing)));
            }

        } else if (n.contains("leftarm") || n.equals("arm_l") || n.equals("left_arm")) {
            if (sitting) {
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-22.5f));
            } else if (carried) {
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-60f));
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(22.5f));
            } else {
                float swing = MathHelper.cos(limbAngle * 0.6662f) * 0.7f * limbDist;
                if (limbDist < 0.01f) swing = MathHelper.sin(animProgress * 0.05f) * 0.04f;
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float) Math.toDegrees(swing)));
            }

        } else if (n.contains("rightleg") || n.equals("leg_r") || n.equals("right_leg")) {
            if (sitting || carried) {
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(sitting ? -45f : 30f));
                if (sitting) matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(22.5f));
            } else {
                float swing = MathHelper.cos(limbAngle * 0.6662f) * 1.0f * limbDist;
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float) Math.toDegrees(swing)));
            }

        } else if (n.contains("leftleg") || n.equals("leg_l") || n.equals("left_leg")) {
            if (sitting || carried) {
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(sitting ? -45f : 30f));
                if (sitting) matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-22.5f));
            } else {
                float swing = MathHelper.cos(limbAngle * 0.6662f + (float) Math.PI) * 1.0f * limbDist;
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float) Math.toDegrees(swing)));
            }
        }
    }

    /**
     * Render 1 cube (6 sisi) dengan UV mapping dari texture sheet.
     * Sistem UV: box mapping (standar Minecraft / Bedrock).
     */
    private void renderCube(YsmModelLoader.Cube c, Matrix4f mat, VertexConsumer vc,
                            int light, int texW, int texH) {
        float x0 = c.ox * PIXEL;
        float y0 = c.oy * PIXEL;
        float z0 = c.oz * PIXEL;
        float x1 = (c.ox + c.sx) * PIXEL;
        float y1 = (c.oy + c.sy) * PIXEL;
        float z1 = (c.oz + c.sz) * PIXEL;

        float sx = c.sx, sy = c.sy, sz = c.sz;
        float u0 = c.u, v0 = c.v;

        // Box UV layout (Minecraft/Bedrock style):
        //   top face:    u0+sz, v0        → u0+sz+sx, v0+sz
        //   bottom face: u0+sz+sx, v0     → u0+sz+sx+sx, v0+sz
        //   front face:  u0+sz, v0+sz     → u0+sz+sx, v0+sz+sy
        //   back face:   u0+sz+sx+sz, v0+sz → u0+sz+sx+sz+sx, v0+sz+sy
        //   left face:   u0, v0+sz        → u0+sz, v0+sz+sy
        //   right face:  u0+sz+sx, v0+sz  → u0+sz+sx+sz, v0+sz+sy

        // Konversi ke [0,1]
        float tw = texW, th = texH;

        // Front (z1 face, normal +Z)
        quad(mat, vc, light,
            x0,y1,z1, x1,y1,z1, x1,y0,z1, x0,y0,z1,
            (u0+sz)/tw, (v0+sz)/th, (u0+sz+sx)/tw, (v0+sz+sy)/th,
            0,0,1);

        // Back (z0 face, normal -Z)
        quad(mat, vc, light,
            x1,y1,z0, x0,y1,z0, x0,y0,z0, x1,y0,z0,
            (u0+sz+sx+sz)/tw, (v0+sz)/th, (u0+sz+sx+sz+sx)/tw, (v0+sz+sy)/th,
            0,0,-1);

        // Top (y1 face, normal +Y)
        quad(mat, vc, light,
            x0,y1,z0, x1,y1,z0, x1,y1,z1, x0,y1,z1,
            (u0+sz)/tw, v0/th, (u0+sz+sx)/tw, (v0+sz)/th,
            0,1,0);

        // Bottom (y0 face, normal -Y)
        quad(mat, vc, light,
            x0,y0,z1, x1,y0,z1, x1,y0,z0, x0,y0,z0,
            (u0+sz+sx)/tw, v0/th, (u0+sz+sx+sx)/tw, (v0+sz)/th,
            0,-1,0);

        // Left (x0 face, normal -X)
        quad(mat, vc, light,
            x0,y1,z0, x0,y1,z1, x0,y0,z1, x0,y0,z0,
            u0/tw, (v0+sz)/th, (u0+sz)/tw, (v0+sz+sy)/th,
            -1,0,0);

        // Right (x1 face, normal +X)
        quad(mat, vc, light,
            x1,y1,z1, x1,y1,z0, x1,y0,z0, x1,y0,z1,
            (u0+sz+sx)/tw, (v0+sz)/th, (u0+sz+sx+sz)/tw, (v0+sz+sy)/th,
            1,0,0);
    }

    /**
     * Emit 4 vertex (satu quad) ke VertexConsumer.
     * u0v0 = UV pojok kiri atas, u1v1 = UV pojok kanan bawah.
     */
    private void quad(Matrix4f mat, VertexConsumer vc, int light,
                      float x0, float y0, float z0,
                      float x1, float y1, float z1,
                      float x2, float y2, float z2,
                      float x3, float y3, float z3,
                      float u0, float v0, float u1, float v1,
                      float nx, float ny, float nz) {
        int overlay = OverlayTexture.DEFAULT_UV;
        vc.vertex(mat, x0,y0,z0).color(1f,1f,1f,1f).texture(u0,v1).overlay(overlay).light(light).normal(nx,ny,nz).next();
        vc.vertex(mat, x1,y1,z1).color(1f,1f,1f,1f).texture(u1,v1).overlay(overlay).light(light).normal(nx,ny,nz).next();
        vc.vertex(mat, x2,y2,z2).color(1f,1f,1f,1f).texture(u1,v0).overlay(overlay).light(light).normal(nx,ny,nz).next();
        vc.vertex(mat, x3,y3,z3).color(1f,1f,1f,1f).texture(u0,v0).overlay(overlay).light(light).normal(nx,ny,nz).next();
    }
}
