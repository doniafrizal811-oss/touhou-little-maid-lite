package com.customplayermodel.client;

import com.customplayermodel.CPMNetwork;
import com.customplayermodel.CPMServerState;
import com.customplayermodel.CustomPlayerModelMod;
import com.customplayermodel.client.model.CPMModelManager;
import com.customplayermodel.client.screen.ModelSelectorScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class CustomPlayerModelClient implements ClientModInitializer {

    /** Tombol buka menu pilih model player: default M */
    public static KeyBinding openModelMenuKey;

    @Override
    public void onInitializeClient() {
        // ── Keybind ────────────────────────────────────────────────────────
        openModelMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.customplayermodel.open_menu",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_M,
            "category.customplayermodel"
        ));

        // ── Registrasi renderer & model layer ─────────────────────────────
        CPMClientRegistry.register();

        // ── Init model manager ─────────────────────────────────────────────
        CPMModelManager.getInstance().init();

        // ── Tick: buka menu saat tombol M ditekan ─────────────────────────
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (openModelMenuKey.wasPressed() && client.player != null) {
                client.setScreen(new ModelSelectorScreen());
            }
        });

        // ── Packet receiver dari server ────────────────────────────────────

        // S2C: maid model berubah → update cache lokal (tidak perlu muat ulang)
        ClientPlayNetworking.registerGlobalReceiver(CPMNetwork.S2C_MAID_MODEL_ID,
            (client, handler, buf, sender) -> {
                int    entityId = buf.readInt();
                String modelId  = buf.readString(64);
                client.execute(() -> {
                    // Tidak perlu pre-load; renderer akan load saat render
                    CustomPlayerModelMod.LOGGER.debug(
                        "[CPM] S2C: maid #{} model = {}", entityId, modelId);
                });
            });

        // S2C: full maid state (model + sit + carry)
        ClientPlayNetworking.registerGlobalReceiver(CPMNetwork.S2C_MAID_STATE_ID,
            (client, handler, buf, sender) -> {
                int     entityId   = buf.readInt();
                String  modelId    = buf.readString(64);
                boolean sitting    = buf.readBoolean();
                boolean carried    = buf.readBoolean();
                boolean hasCarrier = buf.readBoolean();
                java.util.UUID carrierUuid = hasCarrier ? buf.readUuid() : null;

                client.execute(() -> {
                    if (client.world == null) return;
                    net.minecraft.entity.Entity e = client.world.getEntityById(entityId);
                    if (e instanceof com.customplayermodel.entity.MaidEntity maid) {
                        maid.setModelId(modelId);
                        maid.setSitting(sitting);
                        if (carried && carrierUuid != null) {
                            maid.startCarry(carrierUuid);
                        } else {
                            if (maid.isBeingCarried()) maid.stopCarry();
                        }
                    }
                });
            });

        // S2C: carry state berubah
        ClientPlayNetworking.registerGlobalReceiver(CPMNetwork.S2C_CARRY_STATE_ID,
            (client, handler, buf, sender) -> {
                int     entityId = buf.readInt();
                boolean carried  = buf.readBoolean();
                boolean hasCarrier = buf.readBoolean();
                java.util.UUID carrierUuid = hasCarrier ? buf.readUuid() : null;

                client.execute(() -> {
                    if (client.world == null) return;
                    net.minecraft.entity.Entity e = client.world.getEntityById(entityId);
                    if (e instanceof com.customplayermodel.entity.MaidEntity maid) {
                        if (carried && carrierUuid != null) maid.startCarry(carrierUuid);
                        else maid.stopCarry();
                    }
                });
            });

        // ── Bersihkan cache saat shutdown ─────────────────────────────────
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            CPMModelManager.getInstance().clearAll();
            CustomPlayerModelMod.LOGGER.info("[CPM] Model cache cleared.");
        });

        CustomPlayerModelMod.LOGGER.info("[CPM] Client init. Tekan M = pilih model, Shift+klik maid = gendong.");
    }
}
