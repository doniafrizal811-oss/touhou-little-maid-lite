package com.customplayermodel.client;

import com.customplayermodel.client.renderer.MaidEntityModel;
import com.customplayermodel.client.renderer.MaidEntityRenderer;
import com.customplayermodel.entity.ModEntities;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

/**
 * Registrasi semua komponen render client-side.
 * Dipanggil dari CustomPlayerModelClient.onInitializeClient().
 */
public class CPMClientRegistry {

    public static void register() {
        // Daftarkan model layer maid
        EntityModelLayerRegistry.registerModelLayer(
            MaidEntityModel.LAYER_LOCATION,
            MaidEntityModel::getTexturedModelData
        );

        // Daftarkan renderer maid
        EntityRendererRegistry.register(
            ModEntities.MAID,
            MaidEntityRenderer::new
        );
    }
}
