package com.customplayermodel;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Menyimpan state semua player dan maid di sisi server.
 * ConcurrentHashMap = thread-safe, tidak butuh disk I/O per tick.
 */
public class CPMServerState {

    // PlayerUUID -> Model ID ("" = default Steve/Alex)
    private static final Map<UUID, String> playerModels = new ConcurrentHashMap<>();

    public static void setPlayerModel(UUID uuid, String modelId) {
        if (modelId == null || modelId.isBlank()) {
            playerModels.remove(uuid);
        } else {
            playerModels.put(uuid, modelId);
        }
    }

    public static String getPlayerModel(UUID uuid) {
        return playerModels.getOrDefault(uuid, "");
    }

    public static boolean hasCustomModel(UUID uuid) {
        return playerModels.containsKey(uuid) && !playerModels.get(uuid).isBlank();
    }

    public static void removePlayer(UUID uuid) {
        playerModels.remove(uuid);
    }
}
