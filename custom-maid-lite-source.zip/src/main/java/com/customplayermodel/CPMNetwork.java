package com.customplayermodel;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

/**
 * Jaringan mod - menggunakan Fabric Networking API 1.20.1 yang benar.
 * Catatan penting: Fabric 1.20.1 TIDAK mendukung CustomPayload / PayloadTypeRegistry /
 * PacketCodec dari net.minecraft.network.codec — itu API 1.20.4+.
 * Gunakan API lama: Identifier-based channel + PacketByteBuf.
 */
public class CPMNetwork {

    // Channel: client -> server: player memilih model untuk dirinya sendiri
    public static final Identifier SYNC_MODEL_ID =
            new Identifier(CustomPlayerModelMod.MOD_ID, "sync_model");

    // Channel: client -> server: player mengganti model maid miliknya
    public static final Identifier SYNC_MAID_MODEL_ID =
            new Identifier(CustomPlayerModelMod.MOD_ID, "sync_maid_model");

    // Channel: server -> client: broadcast bahwa maid model berubah (semua pemain di sekitar lihat)
    public static final Identifier S2C_MAID_MODEL_ID =
            new Identifier(CustomPlayerModelMod.MOD_ID, "s2c_maid_model");

    // Channel: client -> server: toggle carry (gendong maid)
    public static final Identifier TOGGLE_CARRY_ID =
            new Identifier(CustomPlayerModelMod.MOD_ID, "toggle_carry");

    // Channel: server -> client: broadcast carry state berubah
    public static final Identifier S2C_CARRY_STATE_ID =
            new Identifier(CustomPlayerModelMod.MOD_ID, "s2c_carry_state");

    // Channel: client -> server: toggle sit maid
    public static final Identifier TOGGLE_SIT_ID =
            new Identifier(CustomPlayerModelMod.MOD_ID, "toggle_sit");

    // Channel: server -> client: sync maid state ke klien
    public static final Identifier S2C_MAID_STATE_ID =
            new Identifier(CustomPlayerModelMod.MOD_ID, "s2c_maid_state");

    /**
     * Daftarkan semua receiver di sisi server.
     * Dipanggil dari CustomPlayerModelMod.onInitialize().
     */
    public static void registerServerPackets() {
        // ──────────────────────────────────────────────────────────────
        // 1. Player model sync: client kirim modelId, server simpan di CPMServerState
        // ──────────────────────────────────────────────────────────────
        ServerPlayNetworking.registerGlobalReceiver(SYNC_MODEL_ID,
                (server, player, handler, buf, responseSender) -> {
                    String modelId = buf.readString(64);
                    server.execute(() -> {
                        CPMServerState.setPlayerModel(player.getUuid(), modelId);
                        CustomPlayerModelMod.LOGGER.info("[CPM] {} set player model: {}",
                                player.getName().getString(), modelId);
                    });
                });

        // ──────────────────────────────────────────────────────────────
        // 2. Maid model sync: client kirim entityId + modelId
        // ──────────────────────────────────────────────────────────────
        ServerPlayNetworking.registerGlobalReceiver(SYNC_MAID_MODEL_ID,
                (server, player, handler, buf, responseSender) -> {
                    int entityId = buf.readInt();
                    String modelId = buf.readString(64);
                    server.execute(() -> {
                        net.minecraft.server.world.ServerWorld world =
                                (net.minecraft.server.world.ServerWorld) player.getWorld();
                        net.minecraft.entity.Entity entity = world.getEntityById(entityId);
                        if (entity instanceof com.customplayermodel.entity.MaidEntity maid) {
                            boolean isOwner = player.getUuid().equals(maid.getOwnerUuid());
                            boolean isCreative = player.isCreative();
                            if (isOwner || isCreative) {
                                maid.setModelId(modelId);
                                broadcastMaidModel(world, entityId, modelId);
                                CustomPlayerModelMod.LOGGER.info(
                                        "[CPM] Maid #{} model → {}", entityId, modelId);
                            }
                        }
                    });
                });

        // ──────────────────────────────────────────────────────────────
        // 3. Toggle carry: client minta gendong/lepas maid
        // ──────────────────────────────────────────────────────────────
        ServerPlayNetworking.registerGlobalReceiver(TOGGLE_CARRY_ID,
                (server, player, handler, buf, responseSender) -> {
                    int entityId = buf.readInt();
                    server.execute(() -> {
                        net.minecraft.server.world.ServerWorld world =
                                (net.minecraft.server.world.ServerWorld) player.getWorld();
                        net.minecraft.entity.Entity entity = world.getEntityById(entityId);
                        if (entity instanceof com.customplayermodel.entity.MaidEntity maid) {
                            boolean isOwner = player.getUuid().equals(maid.getOwnerUuid());
                            boolean isCreative = player.isCreative();
                            if (isOwner || isCreative) {
                                maid.toggleCarry(player);
                                // Broadcast state baru ke semua pemain sekitar
                                broadcastMaidState(world, maid);
                            }
                        }
                    });
                });

        // ──────────────────────────────────────────────────────────────
        // 4. Toggle sit: client minta duduk/berdiri maid
        // ──────────────────────────────────────────────────────────────
        ServerPlayNetworking.registerGlobalReceiver(TOGGLE_SIT_ID,
                (server, player, handler, buf, responseSender) -> {
                    int entityId = buf.readInt();
                    server.execute(() -> {
                        net.minecraft.server.world.ServerWorld world =
                                (net.minecraft.server.world.ServerWorld) player.getWorld();
                        net.minecraft.entity.Entity entity = world.getEntityById(entityId);
                        if (entity instanceof com.customplayermodel.entity.MaidEntity maid) {
                            boolean isOwner = player.getUuid().equals(maid.getOwnerUuid());
                            boolean isCreative = player.isCreative();
                            if ((isOwner || isCreative) && !maid.isBeingCarried()) {
                                maid.setSitting(!maid.isSitting());
                                broadcastMaidState(world, maid);
                            }
                        }
                    });
                });
    }

    // ────────────────────────────────────────────────────────────────────
    // Helper: broadcast maid model ke semua pemain di dunia
    // ────────────────────────────────────────────────────────────────────
    public static void broadcastMaidModel(net.minecraft.server.world.ServerWorld world,
                                          int entityId, String modelId) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(entityId);
        buf.writeString(modelId);
        for (net.minecraft.server.network.ServerPlayerEntity p : world.getPlayers()) {
            ServerPlayNetworking.send(p, S2C_MAID_MODEL_ID, buf);
        }
    }

    // ────────────────────────────────────────────────────────────────────
    // Helper: broadcast maid full state (model + sit + carry)
    // ────────────────────────────────────────────────────────────────────
    public static void broadcastMaidState(net.minecraft.server.world.ServerWorld world,
                                          com.customplayermodel.entity.MaidEntity maid) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(maid.getId());
        buf.writeString(maid.getModelId());
        buf.writeBoolean(maid.isSitting());
        buf.writeBoolean(maid.isBeingCarried());
        // Carrier UUID: tulis optional
        java.util.UUID carrierUuid = maid.getCarrierUuid();
        buf.writeBoolean(carrierUuid != null);
        if (carrierUuid != null) buf.writeUuid(carrierUuid);

        for (net.minecraft.server.network.ServerPlayerEntity p : world.getPlayers()) {
            // Buat buf baru tiap player agar tidak korup setelah send
            PacketByteBuf b2 = PacketByteBufs.create();
            b2.writeInt(maid.getId());
            b2.writeString(maid.getModelId());
            b2.writeBoolean(maid.isSitting());
            b2.writeBoolean(maid.isBeingCarried());
            boolean hasCarrier = carrierUuid != null;
            b2.writeBoolean(hasCarrier);
            if (hasCarrier) b2.writeUuid(carrierUuid);
            ServerPlayNetworking.send(p, S2C_MAID_STATE_ID, b2);
        }
    }
}
