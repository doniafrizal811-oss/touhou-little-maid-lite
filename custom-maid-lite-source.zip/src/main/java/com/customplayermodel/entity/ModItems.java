package com.customplayermodel.entity;

import com.customplayermodel.CustomPlayerModelMod;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.*;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class ModItems {

    // Spawn Egg untuk memanggil maid
    public static final SpawnEggItem MAID_SPAWN_EGG = Registry.register(
        Registries.ITEM,
        new Identifier(CustomPlayerModelMod.MOD_ID, "maid_spawn_egg"),
        new SpawnEggItem(
            ModEntities.MAID,
            0xFF88BB, // warna utama (pink muda)
            0xFFDDEE, // warna bintik
            new Item.Settings()
        )
    );

    // Item Group (tab di creative inventory)
    public static final RegistryKey<ItemGroup> CPM_GROUP_KEY =
        RegistryKey.of(
            Registries.ITEM_GROUP.getKey(),
            new Identifier(CustomPlayerModelMod.MOD_ID, "main")
        );

    public static final ItemGroup CPM_GROUP = Registry.register(
        Registries.ITEM_GROUP,
        CPM_GROUP_KEY,
        FabricItemGroup.builder()
            .icon(() -> new ItemStack(MAID_SPAWN_EGG))
            .displayName(Text.translatable("itemGroup.customplayermodel.main"))
            .entries((ctx, entries) -> {
                entries.add(MAID_SPAWN_EGG);
            })
            .build()
    );

    public static void register() {
        CustomPlayerModelMod.LOGGER.info("[CustomMaid] Item terdaftar: maid_spawn_egg");
    }
}
