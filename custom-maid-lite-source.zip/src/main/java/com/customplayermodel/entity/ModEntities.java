package com.customplayermodel.entity;

import com.customplayermodel.CustomPlayerModelMod;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModEntities {

    /**
     * Registrasi entity Maid.
     * Ukuran: 0.6 x 1.8 (sama dengan player, agar model YSM muat pas).
     * trackRangeBlocks=64, trackedUpdateRate=3 → hemat bandwidth.
     */
    public static final EntityType<MaidEntity> MAID = Registry.register(
        Registries.ENTITY_TYPE,
        new Identifier(CustomPlayerModelMod.MOD_ID, "maid"),
        FabricEntityTypeBuilder.create(SpawnGroup.CREATURE, MaidEntity::new)
            .dimensions(EntityDimensions.fixed(0.6f, 1.8f))
            .trackRangeBlocks(64)
            .trackedUpdateRate(3)
            .build()
    );

    public static void register() {
        CustomPlayerModelMod.LOGGER.info("[CustomMaid] Entity terdaftar: maid");
    }
}
