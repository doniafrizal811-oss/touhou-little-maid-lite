package com.customplayermodel.entity;

import com.customplayermodel.CustomPlayerModelMod;
import com.customplayermodel.CPMNetwork;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

/**
 * MaidEntity — companion maid lengkap untuk Fabric 1.20.1.
 */
public class MaidEntity extends TameableEntity {

    // ── NBT keys ─────────────────────────────────────────────────────────
    private static final String NBT_MODEL_ID    = "ModelId";
    private static final String NBT_SITTING     = "Sitting";
    private static final String NBT_CARRYING    = "IsCarried";
    private static final String NBT_CARRIER_UUID = "CarrierUUID";

    // ── State ─────────────────────────────────────────────────────────────
    private String  modelId       = "";
    private boolean isSittingFlag = false;
    private boolean isCarriedFlag = false;
    @Nullable private UUID carrierUuid = null;

    // Cooldown tick agar tick gendong tidak terlalu sering (hemat CPU)
    private int carryTick = 0;
    private static final int CARRY_COOLDOWN = 3; // update posisi tiap 3 tick

    public MaidEntity(EntityType<? extends TameableEntity> type, World world) {
        super(type, world);
        this.setTamed(false);
    }

    // ══════════════════════════════════════════════════════════════════════
    // Attribute default (dipanggil saat daftar entity)
    // ══════════════════════════════════════════════════════════════════════
    public static DefaultAttributeContainer.Builder createMaidAttributes() {
        return MobEntity.createMobAttributes()
            .add(EntityAttributes.GENERIC_MAX_HEALTH,      20.0) // 10 hati
            .add(EntityAttributes.GENERIC_MOVEMENT_SPEED,  0.25) // sedikit lebih lambat player
            .add(EntityAttributes.GENERIC_FOLLOW_RANGE,    16.0) // range follow pendek
            .add(EntityAttributes.GENERIC_ATTACK_DAMAGE,    3.0) // damage cukup (defensive)
            .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.1);
    }

    // ══════════════════════════════════════════════════════════════════════
    // AI Goals
    // ══════════════════════════════════════════════════════════════════════
    @Override
    protected void initGoals() {
        // 1 — Duduk jika diminta
        this.goalSelector.add(1, new SitGoal(this));

        // 2 — Jangan jalan ke bahaya
        this.goalSelector.add(2, new EscapeDangerGoal(this, 1.5));

        // 3 — Balas serang musuh
        this.goalSelector.add(3, new MeleeAttackGoal(this, 1.2, true));

        // 4 — Follow owner
        this.goalSelector.add(4, new FollowOwnerGoal(this, 1.0, 6.0f, 2.0f, false));

        // 5 — Wander (saat tidak ada pemilik / tidak duduk)
        this.goalSelector.add(5, new WanderAroundGoal(this, 0.8, 40));

        // 6 — Lihat player terdekat
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 6.0f));

        // 7 — Lihat ke arah acak
        this.goalSelector.add(7, new LookAroundGoal(this));

        // Target: balas serangan ke diri sendiri
        this.targetSelector.add(1, new TrackOwnerAttackerGoal(this));
        this.targetSelector.add(2, new AttackWithOwnerGoal(this));
        this.targetSelector.add(3, new RevengeGoal(this).setGroupRevenge());
    }

    // ══════════════════════════════════════════════════════════════════════
    // Tick — update posisi saat digendong
    // ══════════════════════════════════════════════════════════════════════
    @Override
    public void tick() {
        super.tick();

        // Kalau sedang digendong, teleport ke bahu carrier
        if (isCarriedFlag && carrierUuid != null && !getWorld().isClient) {
            if (++carryTick >= CARRY_COOLDOWN) {
                carryTick = 0;
                updateCarryPosition();
            }
        }
    }

    /**
     * Update posisi maid ke bahu kanan carrier.
     * Dipanggil server-side setiap CARRY_COOLDOWN tick.
     */
    private void updateCarryPosition() {
        if (!(getWorld() instanceof ServerWorld sw)) return;

        net.minecraft.entity.Entity carrier = null;
        // Cari carrier (player) di dunia
        for (PlayerEntity p : sw.getPlayers()) {
            if (p.getUuid().equals(carrierUuid)) {
                carrier = p;
                break;
            }
        }

        if (carrier == null || !carrier.isAlive()) {
            // Carrier log out / meninggal → lepas
            stopCarry();
            CPMNetwork.broadcastMaidState(sw, this);
            return;
        }

        // Hitung posisi bahu kanan carrier
        float yawRad = (float) Math.toRadians(carrier.getYaw());
        // Offset ke kanan carrier (shoulder)
        double shoulderX = carrier.getX() - Math.sin(yawRad) * 0.35;
        double shoulderY = carrier.getY() + carrier.getStandingEyeHeight() - 0.25;
        double shoulderZ = carrier.getZ() + Math.cos(yawRad) * 0.35;

        // Teleport halus
        this.teleport(shoulderX, shoulderY, shoulderZ);
        this.setVelocity(0, 0, 0);
        this.setYaw(carrier.getYaw());
        this.setPitch(carrier.getPitch() * 0.5f);

        // Pastikan AI tidak jalan sendiri
        this.getNavigation().stop();
    }

    // ══════════════════════════════════════════════════════════════════════
    // Interaksi klik kanan player
    // ══════════════════════════════════════════════════════════════════════
    @Override
    public ActionResult interactMob(PlayerEntity player, Hand hand) {
        ItemStack held = player.getStackInHand(hand);
        World world = this.getWorld();

        // ── Jika belum dijinakkan: tame dengan gula / kue ─────────────────
        if (!this.isTamed()) {
            if (held.isOf(Items.SUGAR) || held.isOf(Items.CAKE)
                    || held.isOf(Items.COOKIE) || held.isOf(Items.WHEAT)) {
                if (!world.isClient) {
                    if (this.random.nextFloat() < 0.33f) {
                        this.setOwner(player);
                        this.setTamed(true);
                        this.setSitting(false);
                        this.playSound(SoundEvents.ENTITY_CAT_PURR, 1.0f, 1.0f);
                        player.sendMessage(
                            Text.translatable("message.customplayermodel.tamed"), true);
                        // Broadcast state ke semua pemain
                        if (world instanceof ServerWorld sw)
                            CPMNetwork.broadcastMaidState(sw, this);
                    } else {
                        this.playSound(SoundEvents.ENTITY_CAT_HISS, 1.0f, 1.0f);
                    }
                    held.decrement(1);
                }
                return ActionResult.SUCCESS;
            }
            return ActionResult.PASS;
        }

        // ── Maid sudah jinak ──────────────────────────────────────────────
        boolean isOwner  = player.getUuid().equals(this.getOwnerUuid());
        boolean creative = player.isCreative();

        // Healing: golden carrot / golden apple / cooked chicken / steak
        if (held.isOf(Items.GOLDEN_CARROT) || held.isOf(Items.GOLDEN_APPLE)
                || held.isOf(Items.COOKED_CHICKEN) || held.isOf(Items.COOKED_BEEF)) {
            if (!world.isClient && this.getHealth() < this.getMaxHealth()) {
                float healAmt = held.isOf(Items.GOLDEN_APPLE) ? 8.0f : 4.0f;
                this.heal(healAmt);
                this.playSound(SoundEvents.ENTITY_GENERIC_EAT, 1.0f, 1.0f);
                if (!player.isCreative()) held.decrement(1);
                player.sendMessage(Text.translatable("message.customplayermodel.heal",
                        String.format("%.1f", this.getHealth()) + "/" + this.getMaxHealth()), true);
                return ActionResult.SUCCESS;
            }
        }

        // Hanya pemilik atau creative yang bisa kontrol
        if (!isOwner && !creative) {
            if (!world.isClient) {
                player.sendMessage(
                    Text.translatable("message.customplayermodel.not_owner"), true);
            }
            return ActionResult.PASS;
        }

        // SHIFT + klik kanan → toggle gendong
        if (player.isSneaking()) {
            if (!world.isClient) {
                toggleCarry(player);
                if (world instanceof ServerWorld sw)
                    CPMNetwork.broadcastMaidState(sw, this);
            }
            return ActionResult.SUCCESS;
        }

        // Klik kanan biasa → toggle duduk (hanya jika tidak sedang digendong)
        if (!isCarriedFlag) {
            if (!world.isClient) {
                boolean newSit = !this.isSitting();
                this.setSitting(newSit);
                this.playSound(newSit ? SoundEvents.ENTITY_CAT_PURR : SoundEvents.ENTITY_CAT_AMBIENT,
                        0.8f, 1.0f);
                player.sendMessage(Text.translatable("message.customplayermodel.sit_toggle",
                        newSit ? "duduk" : "berdiri"), true);
                if (world instanceof ServerWorld sw)
                    CPMNetwork.broadcastMaidState(sw, this);
            }
            return ActionResult.SUCCESS;
        }

        return ActionResult.PASS;
    }

    // ══════════════════════════════════════════════════════════════════════
    // Gendong (Carry/Piggyback) — seperti Little Maid asli
    // ══════════════════════════════════════════════════════════════════════

    public void toggleCarry(PlayerEntity player) {
        if (isCarriedFlag) {
            stopCarry();
            player.sendMessage(
                Text.translatable("message.customplayermodel.carry_stop"), true);
        } else {
            startCarry(player.getUuid());
            setSitting(false); // tidak bisa duduk sambil digendong
            // Disable pathfinding
            this.getNavigation().stop();
            player.sendMessage(
                Text.translatable("message.customplayermodel.carry_start"), true);
        }
    }

    public void startCarry(UUID carrierUuid) {
        this.isCarriedFlag = true;
        this.carrierUuid   = carrierUuid;
        this.carryTick     = 0;
        // Langsung update posisi
        if (!getWorld().isClient) updateCarryPosition();
    }

    public void stopCarry() {
        this.isCarriedFlag = false;
        this.carrierUuid   = null;
    }

    public boolean isBeingCarried() { return isCarriedFlag; }

    @Nullable
    public UUID getCarrierUuid() { return carrierUuid; }

    // ══════════════════════════════════════════════════════════════════════
    // Duduk
    // ══════════════════════════════════════════════════════════════════════
    public void setSitting(boolean sit) {
        this.isSittingFlag = sit;
        this.setInSittingPose(sit);
    }

    public boolean isSitting() { return isSittingFlag; }

    // ══════════════════════════════════════════════════════════════════════
    // Model ID (YSM)
    // ══════════════════════════════════════════════════════════════════════
    public String getModelId() { return modelId; }

    public void setModelId(String id) {
        this.modelId = (id == null) ? "" : id;
    }

    // ══════════════════════════════════════════════════════════════════════
    // Override: jangan serang player / hewan jinak (SUDAH DIPERBAIKI KE LIVINGENTITY)
    // ══════════════════════════════════════════════════════════════════════
    @Override
    public boolean canAttackWithOwner(LivingEntity target, LivingEntity owner) {
        if (target instanceof PlayerEntity) return false; // jangan serang player lain
        return super.canAttackWithOwner(target, owner);
    }

    // ══════════════════════════════════════════════════════════════════════
    // Suara
    // ══════════════════════════════════════════════════════════════════════
    @Override
    protected SoundEvent getAmbientSound() {
        return isSitting() ? SoundEvents.ENTITY_CAT_PURR : SoundEvents.ENTITY_CAT_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_CAT_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_CAT_DEATH;
    }

    @Override
    protected float getSoundVolume() { return 0.6f; }

    // ══════════════════════════════════════════════════════════════════════
    // NBT: simpan & muat semua state
    // ══════════════════════════════════════════════════════════════════════
    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putString(NBT_MODEL_ID, modelId);
        nbt.putBoolean(NBT_SITTING, isSittingFlag);
        nbt.putBoolean(NBT_CARRYING, isCarriedFlag);
        if (carrierUuid != null) nbt.putUuid(NBT_CARRIER_UUID, carrierUuid);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        modelId       = nbt.getString(NBT_MODEL_ID);
        isSittingFlag = nbt.getBoolean(NBT_SITTING);
        isCarriedFlag = nbt.getBoolean(NBT_CARRYING);
        if (nbt.containsUuid(NBT_CARRIER_UUID)) {
            carrierUuid = nbt.getUuid(NBT_CARRIER_UUID);
        }
        // Sinkronisasi pose duduk
        this.setInSittingPose(isSittingFlag);
    }

    // ══════════════════════════════════════════════════════════════════════
    // Spawn validasi & Breeding (SUDAH DIPERBAIKI STANDAR 1.20.1)
    // ══════════════════════════════════════════════════════════════════════
    @Override
    public boolean isBreedingItem(ItemStack stack) {
        return stack.isOf(Items.SUGAR) || stack.isOf(Items.CAKE);
    }

    @Override
    @Nullable
    public PassiveEntity createChild(ServerWorld world, PassiveEntity entity) {
        return null; // maid tidak bisa beranak
    }

    public static void register() {
        CustomPlayerModelMod.LOGGER.info("[CustomMaid] MaidEntity siap.");
    }
}