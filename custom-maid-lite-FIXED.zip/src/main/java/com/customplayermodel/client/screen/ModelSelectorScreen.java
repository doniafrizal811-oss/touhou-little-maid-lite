package com.customplayermodel.client.screen;

import com.customplayermodel.CPMNetwork;
import com.customplayermodel.client.model.CPMModelManager;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.text.Text;

import java.util.*;

/**
 * GUI pilih model untuk PLAYER sendiri.
 * Buka dengan tombol M (default).
 *
 * Navigasi:
 * - Scroll mouse / klik item → pilih model
 * - Terapkan → kirim packet ke server
 * - Reset → kembali ke model default
 * - ⟳ → refresh daftar model dari folder
 */
public class ModelSelectorScreen extends Screen {

    private static final int ITEM_H  = 22;
    private static final int PANEL_W = 220;
    private static final int PANEL_H = 260;

    private final List<String> modelIds   = new ArrayList<>();
    private final List<String> modelNames = new ArrayList<>();
    private int  selectedIndex  = -1;
    private int  scrollOffset   = 0;

    private ButtonWidget applyBtn;

    public ModelSelectorScreen() {
        super(Text.literal("§b✦ Pilih Model Player"));
        Map<String, String> models = CPMModelManager.getInstance().getAvailableModels();
        modelIds.addAll(models.keySet());
        modelNames.addAll(models.values());
    }

    @Override
    protected void init() {
        int px = this.width  / 2 - PANEL_W / 2;
        int py = this.height / 2 - PANEL_H / 2;

        applyBtn = ButtonWidget.builder(
            Text.literal("§aTerapkan"),
            btn -> applyModel()
        ).dimensions(px, py + PANEL_H + 6, PANEL_W / 2 - 3, 20).build();
        applyBtn.active = selectedIndex >= 0;
        this.addDrawableChild(applyBtn);

        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("§cReset Default"),
            btn -> resetModel()
        ).dimensions(px + PANEL_W / 2 + 3, py + PANEL_H + 6, PANEL_W / 2 - 3, 20).build());

        // Tombol refresh (pojok kanan atas panel)
        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("⟳"),
            btn -> refreshList()
        ).dimensions(px + PANEL_W - 22, py - 22, 22, 16).build());
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        this.renderBackground(ctx, mx, my, delta);

        int px = this.width  / 2 - PANEL_W / 2;
        int py = this.height / 2 - PANEL_H / 2;

        // Background panel
        ctx.fill(px - 4, py - 28, px + PANEL_W + 4, py + PANEL_H + 4, 0xBB001A2A);
        ctx.fill(px - 3, py - 27, px + PANEL_W + 3, py - 1, 0xBB002244);

        // Judul
        ctx.drawCenteredTextWithShadow(textRenderer, this.title, this.width / 2, py - 20, 0x88FFFF);

        if (modelIds.isEmpty()) {
            ctx.drawCenteredTextWithShadow(textRenderer,
                Text.literal("§7Tidak ada model.\nTaruh .json di config/customplayermodel/models/"),
                this.width / 2, py + PANEL_H / 2 - 10, 0xFFFFFF);
        } else {
            int visible = PANEL_H / ITEM_H;
            for (int i = 0; i < visible; i++) {
                int idx = i + scrollOffset;
                if (idx >= modelIds.size()) break;

                int iy  = py + i * ITEM_H;
                boolean sel = idx == selectedIndex;
                boolean hov = mx >= px && mx <= px + PANEL_W && my >= iy && my < iy + ITEM_H;

                if (sel)      ctx.fill(px, iy, px + PANEL_W, iy + ITEM_H, 0xBB003366);
                else if (hov) ctx.fill(px, iy, px + PANEL_W, iy + ITEM_H, 0x44FFFFFF);

                String label = (sel ? "§b▶ " : "§7  ") + modelNames.get(idx);
                ctx.drawTextWithShadow(textRenderer, Text.literal(label), px + 6, iy + 7, 0xFFFFFF);
            }

            // Scrollbar
            if (modelIds.size() > visible) {
                int barH  = Math.max(12, PANEL_H * visible / modelIds.size());
                int barY  = py + scrollOffset * PANEL_H / modelIds.size();
                ctx.fill(px + PANEL_W - 4, py, px + PANEL_W, py + PANEL_H, 0x44FFFFFF);
                ctx.fill(px + PANEL_W - 4, barY, px + PANEL_W, barY + barH, 0xAAFFFFFF);
            }
        }

        // Hint kontrol
        ctx.drawCenteredTextWithShadow(textRenderer,
            Text.literal("§8Scroll untuk navigasi · ESC untuk tutup"),
            this.width / 2, py + PANEL_H + 32, 0xFFFFFF);

        super.render(ctx, mx, my, delta);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int px = this.width  / 2 - PANEL_W / 2;
        int py = this.height / 2 - PANEL_H / 2;

        if (mx >= px && mx <= px + PANEL_W - 4 && my >= py && my <= py + PANEL_H) {
            int relY = (int) my - py;
            int idx  = scrollOffset + relY / ITEM_H;
            if (idx >= 0 && idx < modelIds.size()) {
                selectedIndex = idx;
                if (applyBtn != null) applyBtn.active = true;
                // Double-click langsung terapkan
                if (button == 0 && selectedIndex == idx) applyModel();
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        int visible = PANEL_H / ITEM_H;
        int maxScroll = Math.max(0, modelIds.size() - visible);
        scrollOffset = (int) Math.max(0, Math.min(maxScroll, scrollOffset - delta));
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        // Atas / Bawah untuk navigasi
        if (keyCode == 264 || keyCode == 265) { // GLFW_KEY_DOWN / UP
            selectedIndex = Math.max(0, Math.min(modelIds.size() - 1,
                    selectedIndex + (keyCode == 264 ? 1 : -1)));
            if (applyBtn != null) applyBtn.active = selectedIndex >= 0;
            // Auto-scroll
            int visible = PANEL_H / ITEM_H;
            if (selectedIndex < scrollOffset) scrollOffset = selectedIndex;
            if (selectedIndex >= scrollOffset + visible) scrollOffset = selectedIndex - visible + 1;
            return true;
        }
        // Enter untuk terapkan
        if (keyCode == 257 && selectedIndex >= 0) { applyModel(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    // ──────────────────────────────────────────────────────────────────────
    // Aksi
    // ──────────────────────────────────────────────────────────────────────
    private void applyModel() {
        if (selectedIndex < 0 || selectedIndex >= modelIds.size()) return;
        String modelId = modelIds.get(selectedIndex);
        sendModelPacket(modelId);
        this.close();
    }

    private void resetModel() {
        sendModelPacket("");
        this.close();
    }

    private void refreshList() {
        CPMModelManager.getInstance().refreshAvailableModels();
        modelIds.clear();
        modelNames.clear();
        Map<String, String> models = CPMModelManager.getInstance().getAvailableModels();
        modelIds.addAll(models.keySet());
        modelNames.addAll(models.values());
        selectedIndex = -1;
        scrollOffset  = 0;
    }

    private void sendModelPacket(String modelId) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeString(modelId);
        ClientPlayNetworking.send(CPMNetwork.SYNC_MODEL_ID, buf);
    }

    @Override
    public boolean shouldPause() { return false; }
}
